import React from 'react'
import TriangleArea from './components/TriangleArea'

export default function App() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: '20px' }}>
      <h1>Interactive Learning: Area of a Triangle</h1>
      <p>Explore different methods to calculate the area of a triangle.</p>
      <TriangleArea />
    </div>
  )
}
