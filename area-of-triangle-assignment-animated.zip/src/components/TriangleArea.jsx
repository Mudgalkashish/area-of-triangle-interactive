import React, { useState } from 'react'
import { motion } from 'framer-motion'

export default function TriangleArea() {
  const [base, setBase] = useState(100)
  const [height, setHeight] = useState(80)
  const [a, setA] = useState(0)
  const [b, setB] = useState(0)
  const [c, setC] = useState(0)

  const areaBaseHeight = 0.5 * base * height
  const s = (a + b + c) / 2
  const areaHeron = Math.sqrt(s * (s - a) * (s - b) * (s - c)) || 0

  return (
    <div style={{ marginTop: '20px' }}>
      <h2>Interactive Triangle Visualization</h2>
      <svg width="300" height="200" style={{ border: '1px solid #ccc', marginBottom: '20px' }}>
        <motion.polygon
          points={`50,150 ${50 + base},150 50,${150 - height}`}
          fill="lightblue"
          stroke="blue"
          strokeWidth="2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        />
      </svg>
      <p>Move sliders to change Base & Height of the triangle.</p>
      <label>Base: {base}</label><br/>
      <input type="range" min="50" max="200" value={base} onChange={e => setBase(+e.target.value)} /><br/>
      <label>Height: {height}</label><br/>
      <input type="range" min="40" max="150" value={height} onChange={e => setHeight(+e.target.value)} />

      <h3>Method 1: Base & Height</h3>
      <p>Area = 0.5 × base × height = {areaBaseHeight.toFixed(2)}</p>

      <h3>Method 2: Heron's Formula</h3>
      <input type="number" placeholder="Side a" onChange={e => setA(+e.target.value)} />
      <input type="number" placeholder="Side b" onChange={e => setB(+e.target.value)} />
      <input type="number" placeholder="Side c" onChange={e => setC(+e.target.value)} />
      <p>Area = √[s(s-a)(s-b)(s-c)] = {isNaN(areaHeron) ? 'Invalid' : areaHeron.toFixed(2)}</p>
    </div>
  )
}
