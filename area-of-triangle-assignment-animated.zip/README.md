# Area of Triangle - Interactive Educational Module

## Overview
This is a React-based interactive module that teaches **Area of Triangle** (Class 10 level).  
Students can learn different methods:
- Using Base × Height
- Using Heron's Formula

## Features
- Simple UI for input
- Real-time calculation of area
- Demonstrates multiple methods

## Installation
```bash
npm install
npm run dev
```

## Deployment
Deploy easily on **Netlify**, **Vercel**, or GitHub Pages.

## Educational Value
- Enhances conceptual clarity with formulas.
- Interactive input makes learning engaging.

---
Assignment prepared for internship submission.
